<!DOCTYPE html>
<html lang=es>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>
<body>
<?php
$nombre = $_POST['nombre'];
$comentario =$_POST['comentario'];
$mailsend = mail('zepedaroque@hotmail.com','comentarios pasteleria',"Nombre del cliente : $nombre\r\nComentario : $comentario");
if($mailsend){
echo "<p>Hola $nombre Gracias por tu comentario te aseguramos tomarlo en cuenta para mejorar nuestro servicio<p>";
}else {
echo "Lo siento hubo un error en el envio de datos";
}
?>
</body>
</html>