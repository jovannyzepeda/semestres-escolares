/* @Autor  Jovanny Zepeda
    Practica numero 1
    Practica1_SBDA
*/
#include <iostream>
///declaracion de constantes  simbolicas
#define iva 0.16*ingreso
#define retencion_isr 0.1*ingreso
#define retencion_iva 0.1*ingreso
#define isr 0.11*ganancia_bruta
#define gasto_iva 0.16*gasto
using namespace std;
int main()
{
    ///declaracion de constantes
    float subtotal,total,ingreso,gasto,ganancia_bruta,ganancia_neta,isr_pagar,iva_pagar;
    ///ingreso de datos iniciales
    cout<<"Calculo de Impuestos\n"
        <<"Dame el Ingreso:   ";
    cin>>ingreso;
    cout<<"Dame Gasto:   ";
    cin>>gasto;
    ///operaciones sobre las constantes declaradas dentro del main
    subtotal=iva+ingreso;
    total=subtotal-(retencion_isr+retencion_iva);
    ganancia_bruta=ingreso-gasto;
    ganancia_neta=ganancia_bruta-isr;
    isr_pagar=isr-retencion_isr;
    iva_pagar=iva-(retencion_iva+gasto_iva);
    ///impresion de resultados obtenidos tras la realizacion de las operaciones
    cout<<"***Tabla de Recibo de Honorarios***\n"
        <<"Ingreso         "<<ingreso<<"\t\t\tIva             "<<iva<<"\nSubtotal        "<<subtotal
        <<"\t\t\tRetencion ISR   "<<retencion_isr<<"\nRetencion IVA   "<<retencion_iva
        <<"\t\t\tTotal           "<<total<<"\n\n***Total de ganancias***\n"
        <<"Ingreso         "<<ingreso<<"\t\t\tGastos          "<<gasto<<"\nGanancia Bruta  "<<ganancia_bruta
        <<"\t\t\tISR             "<<isr<<"\nGanancia neta   "<<ganancia_neta <<"\n\n***Tabla ISR***\n"
        <<"ISR             "<<isr<<"\t\t\tISR retenido     "<<retencion_isr<<"\nISR a pagar     "<<isr_pagar
        <<"\n\n***Tabla IVA***\n"<<"IVA             "<<iva<<"\t\t\tGastos IVA      "<<gasto_iva<<"\nRetencion IVA   "
        <<retencion_iva<<"\t\t\tIVA a pagar     "<<iva_pagar<<"\nPresiona entrar para terminar...";
    return 0;
}
